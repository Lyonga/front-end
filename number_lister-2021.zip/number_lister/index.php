
<?php require_once("header.php");?>
<br>

  <section id="mainsection" style:background image="\number_lister/images/numbers.jpg">
  <div id="first_div">
      <h2>HOW IT WORKS</h2>
</div>  <br><br> 
  <div id="second_div">
  <article class="first">
      <header id="article_header"><strong>Step One</strong></header><br>
      <img src="images/find.jpg"/>
	    <p>Find valid numbers!</p><br>
  </article>

    <article class="second">
      <header id="article_header"><strong>Step Two</strong></header><br>
      <img src="images/enter.png">
	    <p>Enter in our database!</p><br>
  </article>

    <article class="third">
      <header id="article_header"><strong>Step Three</strong></header><br>
      <img src="images/earn.jpg">
	    <p>Earn money</p><br>
  </article>
</div>
<br><br> <br>
<div id="third_div">
  <article>
      <header id="last_header"><strong>Submit phone numbers and get paid</strong></header><br>
      <img src="images/number.jpg" width="100%" height="450px" alt="number_lister"/><br><br>
	    <p>Just have a heavy phonebook will make you earn cash on the go! Register on our platform and start earning in just one step!</p><br>
  </article>
</div>
</section>
   <?php require_once('footer.php');?>