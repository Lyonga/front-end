<?php

ob_start();
//session_start();

define('DBHOST','localhost');
define('DBUSER','root');
define('DBPASS','');
define('DBNAME','my_list');

define('DIR','number_lister/index.php');

define('DIRADMIN','number_lister/admin/index.php/');

define('SITETITLE','NUMBER LISTER');

//define include checker
define('included', 1);

//include('functions.php');
?>