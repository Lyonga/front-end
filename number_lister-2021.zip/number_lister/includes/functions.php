<?php  
require_once 'config/config.php';  
//session_start();  
class User{
	public $conn;
	public function __construct(){
		$this->conn = new mysqli(DBHOST, DBUSER, DBPASS, DBNAME);

		if(mysqli_connect_errno()) {
			echo "Error: Could not connect to database.";
		 exit;
		}
    }
    
        public function UserRegister($num, $UID, $pwd){  
                $pwd = md5($pwd);
                $result = mysqli_query($this->conn,"INSERT INTO users(u_num, u_name, u_pwd) values('$num', '$UID', '$pwd')") or die(mysql_error());  
                return $result;  
               
        }  
        public function Login($num, $pwd){  
            $pwd = md5($pwd);
            $result = mysqli_query($this->conn, "SELECT * FROM users WHERE u_num = '$num' AND u_pwd = '$pwd'");  
            $user_data = mysqli_fetch_array($result);  
            //print_r($user_data);  
            $no_rows = mysqli_num_rows($result);  
              
            if ($no_rows == 1)   
            {  

            //set cookie to store your login details to the browser to display on fields for any login within an hour
            //$forOneHour = time() + 3600;
		
            if(isset($_POST['remember_me']) && $_POST['remember_me'] == 1){

                setcookie("lister",$row['u_num'],time()+3600,"/");
                setcookie("remember_me",$remember_me,time()+3600,"/");
                
            }
            else
            {
                
                if(isset($_COOKIE['lister']))
                {
                    setcookie("lister","",time()+3600,"/");
                }
                
                if(isset($_COOKIE['remember_me']))
                {
                    setcookie("remember_me","",time()+3600,"/");
                }
            }
           session_start();
                $_SESSION['login'] = true;  
                $_SESSION['uid'] = $user_data['u_id'];  
                $_SESSION['num'] = $user_data['u_num'];
                $_SESSION['UID'] = $user_data['u_name'];
               
                return true;  
            }  
            else  
            {  
                return FALSE;  
            }  
               
                   
        }  
        public function isUserExist($num){  
            $sql = "SELECT * FROM users WHERE u_num = '".$num."'"; 
            $check =  $this->conn->query($sql) ;
            $count_row = $check->num_rows;
  
            if($count_row > 0){  
                return true;  
            } else {  
                return false;  
            }  
        } 
        
        /*** starting the session ***/
        public function get_session(){
            return $_SESSION['login'];
        }

        //logout function
        public function user_logout() {
            setcookie('lister', '', time()-1);
            $_SESSION['login'] = FALSE;
            session_destroy();
        }

    //select email to recover password Function
    public function FetchEmail($mail){
        $oneresult = mysqli_query($this->conn,"SELECT * FROM users WHERE u_email = $mail");
        return $oneresult;
        }
        
        //update new password function
        public function UpdateBlog($pwd){
            $pwd = md5($pwd);
            $updaterecord = mysqli_query($this->conn, "UPDATE users SET u_pwd='$pwd' WHERE u_email = '$mail' ");
            return $updaterecord;
            }

//store token in the password-reset database table against the user's email
public function CreateToken($token, $mail){
    $token = bin2hex(random_bytes(50));
    $result = mysqli_query($this->conn, "INSERT INTO password_reset(token, p_email) values('$token', '$mail')"); 
    return $result; 
}

    //ensure that the user exists on our system to send email to
    public function FetchResetEmail($p_email){
        $oneresult = mysqli_query($this->conn,"SELECT p_email FROM password_reset WHERE token='$token' LIMIT 1");
        return $oneresult;
        }

    }  
?>  