<?php
class UserValidator {

    private $data;
    public  $errors = [];
    private static $fields = ['num', 'UID', 'pwd', 'pwd_repeat'];

    public function __construct( $post_data) {
        $this->data = $post_data;
    }

    public function ValidateForm(){
        foreach(self::$fields as $field){
            if(!array_key_exists($field, $this->data)){
                trigger_error("$field not found");
                return;
            }
        }
        $this->ValidateNumber();
        $this->ValidateName();
        $this->ValidatePassword();
        $this->ValidatePasswordRepeat();
        return $this->errors;
    }

    public function ValidateNumber(){
        $val = trim($this->data['num']);
        if(empty($val)){
            $this->addError('num', 'Phone number cannot be empty');
        }else{
            if(!preg_match("/^[6][0-9]{8, 11}$/", $val)){
                $this->addError('num', 'phone number must be valid cameroon number');
            }else{
                //echo '<div class="input-success"></div>';
                echo "<span>Valid</span>";
                exit;
            }
        }
    }


    public function ValidateName(){
        $val = trim($this->data['UID']);
        if(empty($val)){
            $this->addError('UID', 'Name cannot be empty');
        }else{
            if(!preg_match("/^([a-zA-Z' ]+)$/", $val)){
                $this->addError('UID', 'Name must be valid');
                exit;
            }
        }      
    }

    public function ValidatePassword(){
        $val = trim($this->data['pwd']);
        if(empty($val)){
            $this->addError('pwd', 'Password cannot be empty');
        }else{
            if(!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/", $val)){
                $this->addError('pwd', 'Password must be valid');
                exit;
            }
        }      
    }


    public function ValidatePasswordRepeat(){
        $val = trim($this->data['pwd_repeat']);
        if(empty($val)){
            $this->addError('pwd_repeat', 'password cannot be empty');
        }else{
            if(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/', $val)){
                $this->addError('pwd_repeat', 'Password must be valid');
                exit;
            }
        }      
    }

    public function addError($key, $val){
        $this->errors[$key] = $val;
    }

}
?>

</html>