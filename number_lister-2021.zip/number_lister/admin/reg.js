$(document).ready(function () {
    //validation for phone number
    $('#phone').on('input', function () {
      var phone = $(this).val();
      var validPhone = /^[6][0-9]{8}$/;
    if (phone.length == 0) {
       $('.phone-msg').addClass('invalid-msg').text("Phone number is required");
       $(this).addClass('invalid-input').removeClass('valid-input');
       }
    else if (!validPhone.test(phone)) {
        $('.phone-msg').addClass('invalid-msg').text('only cameroon numbers are allowed');
        $(this).addClass('invalid-input').removeClass('valid-input');
       }
    else {
        $('.phone-msg').empty();
        $(this).addClass('valid-input').removeClass('invalid-input');
        }
       });

        // valiadtion for Email
    $('#email').on('input', function () {
        var email = $(this).val();
        //var validEmail = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i;
        var validEmail = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
     if (email.length == 0) {
        $('.email-msg').addClass('invalid-msg').text("Email is required");
        $(this).addClass('invalid-input').removeClass('valid-input');
        }
    else if (!validEmail.test(email)) {
        $('.email-msg').addClass('invalid-msg').text('Email must be of correct format with @');
        $(this).addClass('invalid-input').removeClass('valid-input');
        }
    else {
        $('.email-msg').empty();
        $(this).addClass('valid-input').removeClass('invalid-input');
        }
        });
    // valiadtion for Name
    $('#name').on('input', function () {
       var name = $(this).val();
       var validName = /^[a-zA-Z ]*$/;
     if (name.length == 0) {
       $('.name-msg').addClass('invalid-msg').text("Name is required");
       $(this).addClass('invalid-input').removeClass('valid-input');
       }
     else if (!validName.test(name)) {
       $('.name-msg').addClass('invalid-msg').text('only letters & Whitespace are allowed');
       $(this).addClass('invalid-input').removeClass('valid-input');
       }
     else {
       $('.name-msg').empty();
       $(this).addClass('valid-input').removeClass('invalid-input');
       }
       });

        // valiadtion for Address
    $('#place').on('input', function () {
        var place = $(this).val();
        var validPlace = /^[a-zA-Z ]*$/;
     if (place.length == 0) {
        $('.place-msg').addClass('invalid-msg').text("Address required");
        $(this).addClass('invalid-input').removeClass('valid-input');
        }
     else if (!validPlace.test(place)) {
        $('.place-msg').addClass('invalid-msg').text('only letters & Whitespace allowed');
        $(this).addClass('invalid-input').removeClass('valid-input');
        }
     else {
        $('.place-msg').empty();
        $(this).addClass('valid-input').removeClass('invalid-input');
        }
        });

            //submit the form

      $('#list_submit').click(function(e){
        e.preventDefault();
        var phone1 = $("#phone").val;
        var email1 = $("#email").val;
        var name1 = $("#name").val;
        var place1 = $("#place").val;

        //var formData = $('#registration').serialize();
        //console.log(formData);

        var dataText = `phone=${phone1}&email=${email1}&name=${name1}&place=${place1}`;
        console.log(dataText);

        $.ajax({
          type: "POST",
          url: "register.php",
          data: 'phone='+phone1 + '&email=' + email1 + '&name=' + name1 + '&place=' + place1,
          success: function(response) {
            $('#message').html(response);/*"<div id='message'></div>
            $('#message').html("<h2>Information Submitted!</h2>")
            .append("<p>Thank you for your submission.</p>")
            .hide()
            .fadeIn(5, function() {
              $('#message').append("<img id='checkmark' src='images/tick.png' />");
              $( '#registration' ).each(function(){
                this.reset();
            });
            });*/
          }
        });
        return false;

    });
    });