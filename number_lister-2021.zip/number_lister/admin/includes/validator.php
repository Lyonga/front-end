<?php
class UserValidator {

    private $data;
    public  $errors = [];
    private static $fields = ['num', 'UID', 'mail', 'add'];

    public function __construct( $post_data) {
        $this->data = $post_data;
    }

    public function ValidateForm(){
        foreach(self::$fields as $field){
            if(!array_key_exists($field, $this->data)){
                trigger_error("$field not found");
                return;
            }
        }
        $this->ValidateNumber();
        $this->ValidateEmail();
        $this->ValidateName();
        $this->ValidateAddress();
        return $this->errors;
    }

    public function ValidateNumber(){
        $val = trim($this->data['num']);
        if(empty($val)){
            $this->addError('num', 'Phone number cannot be empty');
        }else{
            if(!preg_match("/^[6][0-9]{8}$/", $val)){
                $this->addError('num', 'phone number must be valid cameroon number');
            }else{
                echo '<div class="input-success"></div>';
                echo "<span>Valid</span>";
            }
        }
    }

    public function ValidateEmail(){
        $val = trim($this->data['mail']);
        if(empty($val)){
            $this->addError('mail', 'Email cannot be empty');
        }else{
            if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $val)){
                $this->addError('mail', 'Email must be valid');
            }
        }      
    }

    public function ValidateName(){
        $val = trim($this->data['UID']);
        if(empty($val)){
            $this->addError('UID', 'Name cannot be empty');
        }else{
            if(!preg_match("/^[a-zA-Z ]*$/", $val)){
                $this->addError('UID', 'Name must be valid');
            }
        }      
    }

    public function ValidateAddress(){
        $val = trim($this->data['add']);
        if(empty($val)){
            $this->addError('add', 'Address cannot be empty');
        }else{
            if(!preg_match('/^[a-zA-Z ]*$/', $val)){
                $this->addError('add', 'Address must be valid');
                exit;
            }
        }      
    }

    public function addError($key, $val){
        $this->errors[$key] = $val;
    }

/*if(empty($errors)){
	$msg = "num: ".$num.", mail: ".$mail.", UID: ".$UID.", add:".$add;
	echo json_encode(['code'=>200, 'msg'=>$msg]);
	exit;
}


echo json_encode(['code'=>404, 'msg'=>$errors]);*/

}
?>

</html>