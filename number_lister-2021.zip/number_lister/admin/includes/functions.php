<?php
//include_once("../b_header.php");
//include('../config/config.php');
//session_start();  
class User{
	public $conn;
	public function __construct(){
		$this->conn = new mysqli(DBHOST, DBUSER, DBPASS, DBNAME);

		if(mysqli_connect_errno()) {
			echo "Error: Could not connect to database.";
		 exit;
		}
    }

//Enter number function
public function EnterNumber($num, $mail, $UID, $add){  
    $result = mysqli_query($this->conn, "INSERT INTO register(reg_num, reg_email, reg_name, reg_address) values('$num', '$mail', '$UID', '$add')"); 
    return $result; 
}

public function NumberExist($num){  

    $result = mysqli_query($this->conn,"SELECT * FROM register WHERE reg_num = '".$num."'");
   
    $count_row = $result->num_rows;
    
        if ($count_row > 0) {
        
        echo "email already exists";
        return true;  
    } else {  
        return false;  
    } 
}
} 
?>