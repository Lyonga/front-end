
<!Doctype html>
<html lang="en">
<head>
  <title>insert-new-number</title>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="stylesheet" type="text/css" href="style/style.css">
  <link rel="stylesheet" type="text/css" href="style/formhack.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

</head>
<body>
<?php
//session_start();
include_once("b_header.php");
include_once('includes/functions.php');
include_once('includes/validator.php');

$user = new user();

if(isset($_POST['phone'])){

    $num = $_POST['phone'];
    $mail = $_POST['email'];
    $UID = $_POST['name'];
    $add = $_POST['place'];

    $UserValidator = new UserValidator($_POST);
    $errors = $UserValidator->ValidateForm();

    $sql = $user->NumberExist($num);  
    if(!$sql){ 
    $sql = $user->EnterNumber($num, $mail, $UID, $add);
    if($sql){
        echo "Number saved successfully";
        header("Location:index.php");
    }else{
        echo "<p>Something went wrong, contact admin!</p>";
    }
}
}
?>
<div class="validation" style="padding-top:20px;">

<form id="registration" action="register.php" method="POST" style="width:600px; margin-right:auto; margin-left:auto; black; border:2px solid #000; border-radius:10px; padding:20px 20px;font-size:22px;">
<h2 style="text-align:center;padding-bottom:20px;">Please Enter information here<h2>
    
<div id="error_msg"></div>
<div class="form-group">
      <input type="tel" name="num" id="phone" placeholder="Enter Phone Number" value="<?php echo $num ?? '' ?>" minlength="9" required><br>
      <span class="phone-msg"></span>
</div>
<div class="form-group">
      <input type="email" name="mail" id="email" placeholder="Enter email" value="<?php echo $mail ?? '' ?>"><br>
      <span class="email-msg"></span>
</div>
<div class="form-group">
      <input type="text" name="UID" id="name" placeholder="Enter Name" value="<?php echo  $UID ?? '' ?>"><br>
      <span class="name-msg"></span>
</div>
<div class="form-group">
      <input type="text" name="add" id="place" placeholder="Enter Address" value="<?php echo $add ?? '' ?>"><br>
      <span class="place-msg"></span>
</div>
<div class="form-group">
      <button type="button" class="btn btn-primary" name="submit" value="submit" id="list_submit">Register</button>
</div>
<div id="message">
</div>
    </form>
    <style>
    input {
	display: block;
	box-sizing: border-box;
    border: 2px solid grey; 
	width: 100%;
    padding: 8px;
}
.error{
        color:red;
    } 
.has-error, p{
    color:brown;
}
</style>
</div>
</div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script src="../jquery-3.5.1.js"></script>
  <script src="reg.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
</html>