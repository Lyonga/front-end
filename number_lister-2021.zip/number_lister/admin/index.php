<!Doctype html>
<html lang="en">
<head>
<title>admin</title>
<link rel="stylesheet" type="text/css" href="style/admin.css">
</head>
<body>
<?php
include_once("b_header.php");
echo "<br>";
?>
<div class="section">

<div class="entries" style="text-align:right;">
 <button class="btn btn-info"><a href="register.php">Enter Number Here</a></button>
</div>
</div>
</body>
<div class="footer">	
		<div class="copy">&copy; <?php echo SITETITLE.' '. date('Y');?> </div>
</div>
<style>
    .footer{
    text-align:center;
    background-color: navy;
    color:white;
    position: relative;
     min-height: 50px;

}
.copy{
  position: absolute;
  bottom: 0;
  left: 50%;
}
.section{
    height:500px;
}
</style>
</html>